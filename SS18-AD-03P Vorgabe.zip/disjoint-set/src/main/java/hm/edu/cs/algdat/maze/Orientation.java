package hm.edu.cs.algdat.maze;

/**
 * Enum fuer eine Richtung, horizontal oder vertikal.
 * 
 * @author katz.bastian
 */
public enum Orientation {
	HORIZONTAL, VERTICAL
}
