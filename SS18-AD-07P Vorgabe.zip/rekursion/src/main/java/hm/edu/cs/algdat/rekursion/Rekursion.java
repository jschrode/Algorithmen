package hm.edu.cs.algdat.rekursion;

public class Rekursion {

	/**
	 * Testet, ob ein String ein Palindrom ist (case-insensitiv), iterative
	 * Variante.
	 * 
	 * @param string
	 * @return
	 */
	static boolean isPalindromeIterative(String string) {
		return true;
	}

	/**
	 * Testet, ob ein String ein Palindrom ist (case-insensitiv), rekursive
	 * Variante.
	 * 
	 * @param string
	 * @return
	 */
	static boolean isPalindromeRecursive(String string) {
		return true;
	}

	
}
